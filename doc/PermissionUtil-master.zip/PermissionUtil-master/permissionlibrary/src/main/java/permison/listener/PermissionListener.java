package permison.listener;

public interface PermissionListener {
    void havePermission();

    void requestPermissionFail();

}
